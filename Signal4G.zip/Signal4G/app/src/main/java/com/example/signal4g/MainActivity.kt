package com.example.signal4g

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.telephony.CellInfoLte
import android.telephony.TelephonyManager
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

class GraphView(ctx: Context) : View(ctx) {
    val values = ArrayList<Int>()
    private val line = Paint().apply { color = Color.rgb(0, 120, 215); strokeWidth = 5f; style = Paint.Style.STROKE; isAntiAlias = true }
    private val grid = Paint().apply { color = Color.LTGRAY; strokeWidth = 2f }
    private val txt = Paint().apply { color = Color.GRAY; textSize = 28f }
    fun add(v: Int) { values.add(v); if (values.size > 60) values.removeAt(0); invalidate() }
    override fun onDraw(c: Canvas) {
        val min = -140f; val max = -44f
        for (d in listOf(-60, -80, -100, -120)) {
            val y = height * (max - d) / (max - min)
            c.drawLine(0f, y, width.toFloat(), y, grid)
            c.drawText("$d", 6f, y - 4f, txt)
        }
        if (values.size < 2) return
        val p = Path()
        values.forEachIndexed { i, v ->
            val x = width * i / 59f
            val y = height * (max - v.coerceIn(-140, -44)) / (max - min)
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        c.drawPath(p, line)
    }
}

class MainActivity : Activity() {
    private lateinit var tm: TelephonyManager
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var big: TextView
    private lateinit var quality: TextView
    private lateinit var details: TextView
    private lateinit var bar: ProgressBar
    private lateinit var graph: GraphView

    private val tick = object : Runnable {
        override fun run() { update(); handler.postDelayed(this, 1000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40)
        }
        big = TextView(this).apply { textSize = 56f; gravity = Gravity.CENTER; text = "— dBm" }
        quality = TextView(this).apply { textSize = 22f; gravity = Gravity.CENTER }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 96 }
        details = TextView(this).apply { textSize = 18f; setPadding(0, 30, 0, 30) }
        graph = GraphView(this)
        root.addView(big); root.addView(quality)
        root.addView(bar, LinearLayout.LayoutParams(-1, 50))
        root.addView(details)
        root.addView(graph, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.READ_PHONE_STATE), 1)
        }
    }

    override fun onResume() { super.onResume(); handler.post(tick) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(tick) }

    private fun update() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            details.text = "Нужно разрешение на геолокацию (Android требует его для данных о сети)"
            return
        }
        val lte = try { tm.allCellInfo?.filterIsInstance<CellInfoLte>()?.firstOrNull { it.isRegistered }
            ?: tm.allCellInfo?.filterIsInstance<CellInfoLte>()?.firstOrNull() } catch (e: SecurityException) { null }
        if (lte == null) {
            big.text = "— dBm"; quality.text = "4G (LTE) не найден"
            details.text = "Оператор: ${tm.networkOperatorName}"
            return
        }
        val s = lte.cellSignalStrength
        val rsrp = s.rsrp
        big.text = "$rsrp dBm"
        val (q, color) = when {
            rsrp >= -80 -> "Отличный" to Color.rgb(0, 160, 0)
            rsrp >= -90 -> "Хороший" to Color.rgb(100, 180, 0)
            rsrp >= -100 -> "Средний" to Color.rgb(230, 160, 0)
            rsrp >= -110 -> "Слабый" to Color.rgb(230, 90, 0)
            else -> "Очень слабый" to Color.RED
        }
        quality.text = q; quality.setTextColor(color); big.setTextColor(color)
        bar.progress = (rsrp.coerceIn(-140, -44) + 140)
        val sinr = if (s.rssnr == Int.MAX_VALUE) "—" else "${s.rssnr} dB"
        val rsrq = if (s.rsrq == Int.MAX_VALUE) "—" else "${s.rsrq} dB"
        details.text = "Оператор: ${tm.networkOperatorName}\n" +
            "RSRP: $rsrp dBm\nRSRQ: $rsrq\nSINR: $sinr\n" +
            "Уровень: ${s.level}/4\nБазовая станция (CI): ${lte.cellIdentity.ci}"
        graph.add(rsrp)
    }
}
